#include <Arduino.h>
#include "Wire.h"
#include "TCS34725AutoGain.h"

#ifndef linesense_h
#define linesense_h 

class LineSense{

};

#endif